/** @type {import('next').NextConfig} */
const nextConfig = {
    output: 'standalone',
    pageExtensions: ['tsx', 'ts', 'jsx', 'js'],
  };
  
  export default nextConfig;
  