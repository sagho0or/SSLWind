
export interface IconsProps {
  name: string;
  width?: string;
  height?: string;
  customStyle?: string
}