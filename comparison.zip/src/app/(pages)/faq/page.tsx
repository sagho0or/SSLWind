import FAQ from "@/app/components/FAQ";

export default function FaqPage() {
    return (
        <FAQ />
    )
}