import Security from "@/app/components/Security";

export default function SecurityPage() {
    return (
        <Security />
    )
}