import SafeLLM from '@/app/components/SafeLLM';

export default async function Home() {
  return (
    <SafeLLM />
  );
}

