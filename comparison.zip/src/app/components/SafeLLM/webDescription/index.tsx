export default function WebComparisonDescription() {

    return (
        <div className={"mt-20 "}>

        </div>
    );
}