export interface ToggleButtonInterface{
    side: string,
    handleTabClick: (side : string )=>void
}