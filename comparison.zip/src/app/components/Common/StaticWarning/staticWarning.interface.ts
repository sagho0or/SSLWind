export interface StaticWarningInterface {
    text: string;
    customStyle?: string;
    iconWidth?: string;
}