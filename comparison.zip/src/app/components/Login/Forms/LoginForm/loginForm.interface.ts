export interface LoginFormProps{
  confirmFunction: (mobile : string , password: string)=>void
}