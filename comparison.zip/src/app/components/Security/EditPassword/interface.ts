export interface EditPasswordInterface {
    setIsEditPasswordOpen: (arg: boolean) => void,
    isEditPasswordOpen: boolean
}