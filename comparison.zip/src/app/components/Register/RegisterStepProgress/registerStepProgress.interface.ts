export interface RegisterStepProgressInterface{
  step: number
}