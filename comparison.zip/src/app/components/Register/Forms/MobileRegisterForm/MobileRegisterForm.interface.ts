export interface MobileRegisterFormInterface{
  setMobile: (mobile:string)=>void;
  mobile: string
}