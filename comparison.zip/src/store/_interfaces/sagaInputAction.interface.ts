export interface SagaInputActionInterface{
  data:object;
  type: string;
}