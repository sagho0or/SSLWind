export interface StateInterface{
  isLoading: boolean;
  isDone: boolean;
  hasError: string;
  data: object
}