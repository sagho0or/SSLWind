export interface registerResendOtpRequestInterface {
  password: string;
  mobile: string;
  //TODO
  //recaptcha_response: string;
}
