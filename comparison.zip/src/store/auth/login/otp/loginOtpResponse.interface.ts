export interface LoginOtpResponseInterface{
  refresh_token:string,
  token: string
}