export interface LoginOtpInterface{
  code: string,
  mobile: string,
  tracking_id: string
}