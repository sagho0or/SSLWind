export interface HistoryInterface {
    offset: number,
    limit: number
}