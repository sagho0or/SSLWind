export interface OredrHistoryInterface {
    offset: number,
    limit: number,
    from_date?: string,
    to_date?: string,
}