export interface change2FAdataInterface {
    login_otp_type: number,
    withdraw_otp_type: number
}